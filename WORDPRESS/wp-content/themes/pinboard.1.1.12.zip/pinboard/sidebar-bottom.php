<?php if( is_active_sidebar( 5 ) ) : ?>
	<div id="sidebar-bottom" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 5 ) ; ?>
	</div><!-- #sidebar-bottom -->
<?php endif; ?>
== Aqueduct ==
Tested up to: WordPress 4.4
Version: 1.5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Copyright (c) 2015 by Aqueduct Theme (http://howlthemes.com/)
This Theme is distributed under the terms of the GNU GPL.

Supported browsers: Firefox, Opera, Chrome, Safari and IE9+ (Some css3 styles like shadows, rounder corners are not supported by IE8 and below).


== Description ==
Aqueduct is easy to use minimal magazine/blog theme for wordpress. It has advance theme builder which let you customize this theme without even touching a single line of code, This Theme is compatible with WooCommerce and BBPress.

For free themes support, please contact us http://howlthemes.com


== Copyright ==

Aqueduct Theme bundles the following third-party resources:

Font Awesome by Dave Gandy
License: SIL OFL 1.1
Source: http://fontawesome.io/icons/ 

Basic jQuery Slider plug-in v.1.3
License: GNU General Public License, version 3 (GPL-3.0)
Source: http://www.basic-slider.com

JQuery Advanced News Ticker 1.0.11 by risq
License: GNU General Public License, Version 2
Source : http://risq.github.io/jquery-advanced-news-ticker/

tinycarousel - v2.1.8 Copyright (c) 2015 Maarten Baijs
License: MIT
Source: https://baijs.com/tinycarousel

tinynav - Copyright (c) 2011-2014 Viljami Salminen
License: MIT
Source: http://tinynav.viljamis.com

Image used in screenshot.png: 

A photo by Abigail Keenan (https://unsplash.com/akeenster), licensed under Creative Commons Zero(http://creativecommons.org/publicdomain/zero/1.0/)

A photo by Andrew Phillips (https://unsplash.com/andrewjohnp), licensed under Creative Commons Zero(http://creativecommons.org/publicdomain/zero/1.0/)

A photo by Stefan Kunze (https://unsplash.com/stefankunze), licensed under Creative Commons Zero(http://creativecommons.org/publicdomain/zero/1.0/)
